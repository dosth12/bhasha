export interface Role{
   
        roleName:string,
        roleDescription:string

}